#pragma once
#include<string>
using namespace std;
struct Info
{
	double similarity;
	string hash_val;
	int flag;
};
double count_same(string a, string b);
void random_change(string s,Info a[]);
string conform(int a);
void data_sort(Info table[]);