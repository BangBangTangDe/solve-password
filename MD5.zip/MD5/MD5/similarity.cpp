#include"stdafx.h"
#include"md5.h"
#include"similarity.h"
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<stack>
#include<time.h>
#pragma warning (disable:4996)
using namespace std;
bool cmp(Info a, Info b) {
	return a.similarity < b.similarity;
}
char ahex[16] = { '0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
//ʮ�����Ƶ�ת������
string conform(int a)
{
	stack<char> ans;
	if (a == 0)return "00";
	else if (a >= 0 && a <= 15)
	{
		string tmp = "0";
		tmp  += ahex[a];
		return tmp;
	}
	while (a)
	{
		ans.push(ahex[a%16]);
		a >>= 4;
	}
	string s = "";
	while (!ans.empty())
	{
		s += ans.top();
		ans.pop();
	}
	return s;
}
//����ı������е�ĳһλ���ַ�
void change_onechar(string &s)
{
	int len = s.length();
	int pos = rand() % (len-1);

	char ch = 'a' + rand() % 25;
	cout << "λ�ã�" <<"��"<< pos <<"λ"<<"�ַ���"<<s[pos]<<"->"<<ch << endl;
	s[pos] = ch;
}
//�������ƶ�
double count_same(string a, string b) {

	double res = 0;
	int n = (int)a.size(), m = (int)b.size();
	vector<vector<int>>dp(n + 1, vector<int>(m + 1, 0));
	dp[0][0] = 0;//dp[x][y]������a�ַ���ǰx���ַ��޸ĳ�b�ַ���ǰy���ַ�
	for (int i = 1; i <= m; ++i)
		dp[0][i] = i;
	for (int i = 1; i <= n; ++i)
		dp[i][0] = i;
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= m; ++j)
		{
			int one = dp[i - 1][j] + 1, two = dp[i][j - 1] + 1, three = dp[i - 1][j - 1];
			if (a[i - 1] != b[j - 1])
				three += 1;
			dp[i][j] = min(min(one, two), three);
		}
	}
	res = 1.0 / (1 + dp[n][m]);
	return res;
}
//����ı��ַ��������µ�hash����,ִ��ʮ��
void  random_change(string s,Info hash[])
{
	int i = 0;
	string mingwen = s;
	
	unsigned char * encrypt = (unsigned char *)s.c_str();//�����ַ��� 
	unsigned char decrypt[16];
	MD5_CTX md5;
	MD5Init(&md5);
	MD5Update(&md5, encrypt, strlen((char *)encrypt));
	MD5Final(&md5, decrypt);
	string result = "";
	for (int i = 4; i <= 12; i++)
	{
		result += conform((int)decrypt[i]);
	}
	cout << endl;
	cout << "here=>" << result << endl;
	while (i < 10)
	{
		string result1 = "";
		change_onechar(mingwen);
		unsigned char * encrypt = (unsigned char *)mingwen.c_str();//�����ַ��� 
		unsigned char decrypt[16];
		MD5_CTX md5;
		MD5Init(&md5);
		MD5Update(&md5, encrypt, strlen((char *)encrypt));
		MD5Final(&md5, decrypt);
		for (int i = 4; i <= 12; i++)
		{
			result1 += conform((int)decrypt[i]);
		}
		hash[i].similarity= count_same(result, result1);
		hash[i].flag = i + 1;
		hash[i].hash_val = result1;
		cout << "H" << i+1<<":"<<hash[i].hash_val<< "��H0�����ƶȣ�" << hash[i].similarity << endl;
		i++;
	}
}
void data_sort(Info table[]) {
	double ans = 0;
	sort(table, table + 10, cmp);
	cout << "=======���ƶ�����=======" << endl;
	for (int i = 0; i < 10; i++)
	{
		cout <<i+1<< "     :H0��" << "H" << table[i].flag<<":"<<table[i].hash_val << "���ƶ�=��" << table[i].similarity << endl;
		ans += table[i].similarity;
	}
	cout << "���ƶ�ƽ��ֵ :" << ans * 1.0 / 10 << endl;
}
